import { Shield, Lock, Eye, Key } from "lucide-react"

const providers = [
  { name: "Adobe", abbr: "Ae" },
  { name: "AWS S3", abbr: "S3" },
  { name: "Backblaze", abbr: "B2" },
  { name: "Wasabi", abbr: "W" },
  { name: "Google Cloud", abbr: "GCS" },
  { name: "Dropbox", abbr: "DB" },
]

const securityPoints = [
  { icon: Lock, text: "Credentials stored locally with encryption" },
  { icon: Eye, text: "Read-only mode available for extra safety" },
  { icon: Key, text: "Direct API connection — we never see your files" },
]

const testimonials = [
  {
    quote: "Finally, I can actually find my footage without downloading everything first.",
    author: "Sarah M.",
    role: "Freelance Editor",
  },
  {
    quote: "The Share Project feature alone saved us hours of 'Media Offline' troubleshooting.",
    author: "James K.",
    role: "Post-Production Lead",
  },
  {
    quote: "Switched from a $500/mo MAM to Sofile. Does 80% of what I need at a fraction of the cost.",
    author: "Mike R.",
    role: "Studio Owner",
  },
]

export function TrustLogos() {
  return (
    <section className="relative py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6 space-y-10">
        {/* Security block */}
        <div className="rounded-xl border border-border/50 bg-card/30 p-6 md:p-8 backdrop-blur-xl">
          <div className="flex flex-col items-center text-center lg:flex-row lg:items-start lg:text-left lg:gap-12">
            <div className="shrink-0">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2 text-sm text-primary">
                <Shield className="h-4 w-4" />
                Secure by Design
              </div>
              <h3 className="text-xl font-semibold text-foreground">
                Direct connection. No file storage.
              </h3>
              <p className="mt-2 text-sm text-muted-foreground max-w-md">
                We connect directly to your cloud via official APIs. Your files never pass through our servers.
              </p>
            </div>
            
            <div className="mt-6 lg:mt-0 flex-1">
              <div className="grid gap-3 sm:grid-cols-3">
                {securityPoints.map((point, i) => (
                  <div key={i} className="flex items-start gap-3 rounded-lg border border-border/30 bg-secondary/30 p-3">
                    <point.icon className="h-4 w-4 shrink-0 text-primary mt-0.5" />
                    <span className="text-xs text-muted-foreground leading-relaxed">{point.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div>
          <p className="text-center text-sm text-muted-foreground mb-6">What beta users are saying</p>
          <div className="grid gap-4 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <div key={i} className="rounded-xl border border-border/50 bg-card/30 p-5 backdrop-blur-xl">
                <p className="text-sm text-foreground/90 leading-relaxed">"{t.quote}"</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center text-xs font-medium text-muted-foreground">
                    {t.author.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-xs font-medium text-foreground">{t.author}</p>
                    <p className="text-[10px] text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Integration logos */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-6">Works with your existing stack</p>
          <div className="flex flex-wrap items-center justify-center gap-4 md:gap-6">
            {providers.map((provider, i) => (
              <div
                key={i}
                className="flex flex-col items-center gap-1.5 text-muted-foreground transition-colors hover:text-foreground"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-border/50 bg-secondary/50 transition-all hover:border-border hover:bg-secondary">
                  <span className="text-sm font-semibold">{provider.abbr}</span>
                </div>
                <span className="text-[10px]">{provider.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
