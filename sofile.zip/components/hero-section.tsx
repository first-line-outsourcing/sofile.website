import { Button } from "@/components/ui/button"
import { ArrowRight, Play, Check } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden pt-28 pb-16 md:pt-36 md:pb-24">
      {/* Background gradient */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 h-[500px] w-[700px] -translate-x-1/2 rounded-full bg-primary/8 blur-[100px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="flex flex-col lg:block">
          {/* Left content */}
          <div className="relative z-10 text-center lg:max-w-[50%] lg:text-left">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-border/50 bg-secondary/50 px-4 py-1.5 text-sm text-muted-foreground backdrop-blur-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
              Now in Public Beta
            </div>
            
            <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground md:text-5xl lg:text-6xl">
              Your Cloud Storage.{" "}
              <span className="text-primary">
                Native in Adobe.
              </span>
            </h1>
            
            <p className="mt-5 text-pretty text-lg text-muted-foreground">
              Search, preview, and edit media from S3, Backblaze, or Dropbox without leaving your creative apps.
            </p>

            {/* 3 Bullets */}
            <ul className="mt-6 space-y-2.5 text-left">
              {[
                "Visual search and preview in cloud",
                "Drag assets directly to timeline",
                "Share projects with zero \"Media Offline\"",
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-foreground/80">
                  <Check className="h-4 w-4 shrink-0 text-primary" />
                  <span className="text-sm">{item}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row lg:justify-start">
              <Button size="lg" className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90 sm:w-auto">
                Start Free
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="w-full gap-2 border-border bg-transparent text-foreground hover:bg-secondary sm:w-auto">
                <Play className="h-4 w-4" />
                Watch Demo
              </Button>
            </div>

            <p className="mt-3 text-sm text-muted-foreground">
              Free plan includes 1 cloud connection. No credit card required.
            </p>
          </div>

          {/* Hero mockup image - stacks below on mobile, floats right on desktop */}
          <div className="relative mt-12 lg:mt-0 lg:absolute lg:top-1/2 lg:left-[45%] lg:-translate-y-1/2">
            <Image
              src="/images/landing-banner-bg.png"
              alt="Sofile plugin integrated with Adobe Premiere Pro showing cloud storage management and video editing"
              width={1200}
              height={800}
              className="w-full max-w-[90vw] lg:max-w-[80vw] lg:w-[80vw] drop-shadow-2xl"
              priority
            />
          </div>
        </div>
      </div>
    </section>
  )
}
