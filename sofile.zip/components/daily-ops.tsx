import { ImageIcon, FileText, Tag, ArrowUpDown, GitBranch, HardDrive } from "lucide-react"

const ops = [
  {
    icon: ImageIcon,
    title: "Thumbnails & Waveforms",
    value: "See inside files",
    description: "Preview video and audio without downloading.",
    span: "col-span-1",
  },
  {
    icon: FileText,
    title: "Bulk Rename Templates",
    value: "Fix messy names",
    description: "Apply naming conventions across folders.",
    span: "col-span-1",
  },
  {
    icon: Tag,
    title: "Sidecar Metadata",
    value: "Tag and describe",
    description: "Add notes, tags, and descriptions. MAM-lite.",
    span: "col-span-1",
  },
  {
    icon: ArrowUpDown,
    title: "Transfer Queue",
    value: "Reliable uploads",
    description: "Resumable transfers with progress tracking.",
    span: "col-span-1",
  },
  {
    icon: GitBranch,
    title: "Version Control",
    value: "Track changes",
    description: "See project versions across your archive.",
    span: "col-span-1",
  },
  {
    icon: HardDrive,
    title: "Smart Cache",
    value: "Offline access",
    description: "Keep frequently used assets locally synced.",
    span: "col-span-1",
  },
]

export function DailyOps() {
  return (
    <section className="relative py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-border/50 bg-secondary/50 px-4 py-1.5 text-sm text-muted-foreground">
            Daily Toolkit
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Daily Media Ops
          </h2>
        </div>

        {/* Bento grid */}
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {ops.map((op, i) => (
            <div
              key={i}
              className={`group rounded-xl border border-border/50 bg-card/30 p-5 backdrop-blur-xl transition-all hover:border-primary/30 hover:bg-card/50 ${op.span}`}
            >
              <div className="mb-4 flex h-9 w-9 items-center justify-center rounded-lg border border-border/50 bg-secondary/50 transition-colors group-hover:border-primary/30 group-hover:bg-primary/10">
                <op.icon className="h-4 w-4 text-muted-foreground transition-colors group-hover:text-primary" />
              </div>
              <p className="text-sm font-semibold text-foreground">{op.value}</p>
              <p className="mt-1 text-xs text-muted-foreground">{op.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
