"use client"

import { useState, useRef, useEffect } from "react"

export function ProblemSolution() {
  const [sliderPosition, setSliderPosition] = useState(50)
  const containerRef = useRef<HTMLDivElement>(null)
  const isDragging = useRef(false)

  const handleMove = (clientX: number) => {
    if (!containerRef.current || !isDragging.current) return
    const rect = containerRef.current.getBoundingClientRect()
    const x = clientX - rect.left
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100))
    setSliderPosition(percentage)
  }

  const handleMouseDown = () => {
    isDragging.current = true
  }

  const handleMouseUp = () => {
    isDragging.current = false
  }

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => handleMove(e.clientX)
    const handleTouchMove = (e: TouchEvent) => handleMove(e.touches[0].clientX)
    
    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
    window.addEventListener('touchmove', handleTouchMove)
    window.addEventListener('touchend', handleMouseUp)
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
      window.removeEventListener('touchmove', handleTouchMove)
      window.removeEventListener('touchend', handleMouseUp)
    }
  }, [])

  return (
    <section className="relative py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Stop digging through browser tabs.
          </h2>
          <p className="mt-3 text-pretty text-muted-foreground">
            Turn cloud buckets into a visual media library inside Adobe.
          </p>
        </div>

        {/* Interactive before/after slider */}
        <div className="mt-12">
          <div 
            ref={containerRef}
            className="relative mx-auto max-w-5xl cursor-ew-resize overflow-hidden rounded-xl border border-border/50"
            onMouseDown={handleMouseDown}
            onTouchStart={handleMouseDown}
          >
            {/* Before (S3 Console) - Full width background */}
            <div className="relative bg-[#232f3e] p-4 md:p-6">
              <div className="mb-3 flex items-center gap-2 text-xs text-orange-400/80">
                <div className="flex h-5 w-5 items-center justify-center rounded bg-orange-400/20 text-[10px] font-bold">S3</div>
                AWS S3 Console
              </div>
              <div className="space-y-1.5">
                {[
                  "C001_V1_001.mp4",
                  "C001_V1_002.mp4", 
                  "C001_V1_003_FINAL.mp4",
                  "C001_V1_003_FINAL_v2.mp4",
                  "interview_raw_01.mov",
                  "interview_raw_02.mov",
                  "broll_drone_sunset.mp4",
                  "broll_drone_sunset_graded.mp4",
                ].map((file, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between rounded border border-neutral-600/30 bg-neutral-800/50 px-3 py-2"
                  >
                    <span className="font-mono text-xs text-neutral-400">{file}</span>
                    <span className="text-[10px] text-neutral-500">
                      {Math.floor(Math.random() * 400 + 100)} MB
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* After (Sofile) - Overlay with clip */}
            <div 
              className="absolute inset-0 overflow-hidden"
              style={{ clipPath: `inset(0 0 0 ${sliderPosition}%)` }}
            >
              <div className="h-full bg-card/95 p-4 md:p-6">
                <div className="mb-3 flex items-center gap-2 text-xs text-primary">
                  <div className="flex h-5 w-5 items-center justify-center rounded bg-primary/20 text-[10px] font-bold">So</div>
                  Sofile Panel
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
                  {[
                    { name: "Drone Sunset", duration: "02:34", type: "video" },
                    { name: "Interview John", duration: "15:22", type: "video" },
                    { name: "B-Roll City", duration: "01:45", type: "video" },
                    { name: "Final Cut v2", duration: "08:12", type: "video" },
                    { name: "Music Track", duration: "03:45", type: "audio" },
                    { name: "SFX Whoosh", duration: "00:08", type: "audio" },
                    { name: "Intro Anim", duration: "00:12", type: "video" },
                    { name: "Outro", duration: "00:15", type: "video" },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="overflow-hidden rounded-lg border border-border/30 bg-secondary/50"
                    >
                      <div className={`relative aspect-video ${
                        item.type === "video" 
                          ? 'bg-gradient-to-br from-primary/30 to-primary/10'
                          : 'bg-secondary'
                      }`}>
                        {item.type === "audio" && (
                          <div className="flex h-full items-center justify-center gap-0.5 px-3">
                            {[...Array(16)].map((_, j) => (
                              <div
                                key={j}
                                className="w-0.5 rounded-full bg-primary/60"
                                style={{ height: `${Math.random() * 50 + 30}%` }}
                              />
                            ))}
                          </div>
                        )}
                        <div className="absolute bottom-1 right-1 rounded bg-background/80 px-1 py-0.5 text-[9px] text-muted-foreground">
                          {item.duration}
                        </div>
                      </div>
                      <div className="p-2">
                        <p className="truncate text-[11px] font-medium text-foreground">{item.name}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Slider handle */}
            <div 
              className="absolute top-0 bottom-0 z-10 w-1 bg-primary cursor-ew-resize"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex h-10 w-10 items-center justify-center rounded-full border-2 border-primary bg-background shadow-lg">
                <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 8l4 4-4 4M6 8l-4 4 4 4" />
                </svg>
              </div>
            </div>

            {/* Labels */}
            <div className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-orange-400/20 px-2.5 py-1 text-[10px] font-medium text-orange-400">
              Before
            </div>
            <div className="pointer-events-none absolute bottom-3 right-3 rounded-full bg-primary/20 px-2.5 py-1 text-[10px] font-medium text-primary">
              After
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
