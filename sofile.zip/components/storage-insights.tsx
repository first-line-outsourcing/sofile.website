"use client"

import { Button } from "@/components/ui/button"
import { HardDrive, Snowflake, Copy, DollarSign, Archive, Trash2, ArrowDownToLine } from "lucide-react"

const metrics = [
  { 
    icon: HardDrive, 
    label: "Total Storage", 
    value: "2.4 TB", 
    subtext: "Across 3 buckets" 
  },
  { 
    icon: Snowflake, 
    label: "Cold Data", 
    value: "890 GB", 
    subtext: "Not accessed in 90+ days" 
  },
  { 
    icon: Copy, 
    label: "Duplicates", 
    value: "156 GB", 
    subtext: "47 duplicate files found" 
  },
  { 
    icon: DollarSign, 
    label: "Monthly Waste", 
    value: "$67", 
    subtext: "Potential savings" 
  },
]

const actions = [
  { icon: Archive, label: "Archive cold data", savings: "$42/mo" },
  { icon: Trash2, label: "Remove duplicates", savings: "$18/mo" },
  { icon: ArrowDownToLine, label: "Move to cheaper tier", savings: "$7/mo" },
]

export function StorageInsights() {
  return (
    <section id="insights" className="relative py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary">
            <DollarSign className="h-3.5 w-3.5" />
            Save Money
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Know what you pay for.
          </h2>
          <p className="mt-3 text-pretty text-muted-foreground">
            Identify cold data and duplicates. See exactly where your money goes.
          </p>
        </div>

        {/* Money moment dashboard */}
        <div className="mt-10 rounded-xl border border-border/50 bg-card/50 p-5 md:p-8 backdrop-blur-xl">
          {/* Metrics grid */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {metrics.map((metric, i) => (
              <div key={i} className="rounded-xl border border-border/30 bg-secondary/30 p-4">
                <metric.icon className={`mb-3 h-5 w-5 ${i === 3 ? 'text-primary' : 'text-muted-foreground'}`} />
                <p className="text-2xl font-bold text-foreground">{metric.value}</p>
                <p className="text-sm font-medium text-foreground/80">{metric.label}</p>
                <p className="mt-1 text-xs text-muted-foreground">{metric.subtext}</p>
              </div>
            ))}
          </div>

          {/* Visual bar */}
          <div className="mt-6 rounded-xl border border-border/30 bg-secondary/20 p-4">
            <div className="mb-3 flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Storage Breakdown</span>
              <span className="text-foreground font-medium">2.4 TB total</span>
            </div>
            <div className="flex h-8 overflow-hidden rounded-lg">
              <div className="flex-[1.2] bg-primary/60 flex items-center justify-center text-[10px] font-medium text-primary-foreground">Active</div>
              <div className="flex-[0.9] bg-primary/30 flex items-center justify-center text-[10px] font-medium text-foreground/70">Cold</div>
              <div className="flex-[0.15] bg-destructive/50 flex items-center justify-center text-[10px] font-medium text-foreground/70">Dupe</div>
              <div className="flex-[0.15] bg-muted-foreground/30" />
            </div>
            <div className="mt-2 flex items-center gap-4 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded bg-primary/60" /> Active (1.2 TB)</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded bg-primary/30" /> Cold (890 GB)</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded bg-destructive/50" /> Duplicates (156 GB)</span>
            </div>
          </div>

          {/* Action chips */}
          <div className="mt-6 flex flex-wrap gap-3">
            {actions.map((action, i) => (
              <Button 
                key={i} 
                variant="outline" 
                size="sm" 
                className="gap-2 border-primary/30 bg-primary/5 text-foreground hover:bg-primary/10 hover:border-primary/50"
              >
                <action.icon className="h-3.5 w-3.5 text-primary" />
                {action.label}
                <span className="text-primary font-medium">{action.savings}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
