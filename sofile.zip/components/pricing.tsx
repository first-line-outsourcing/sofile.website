import { Button } from "@/components/ui/button"
import { Check, Sparkles, ArrowRight, Users } from "lucide-react"

const plans = [
  {
    name: "Free",
    price: "$0",
    description: "For trying out Sofile",
    features: [
      "1 Cloud Provider",
      "Basic file search",
      "Thumbnail preview",
      "Community support",
    ],
    cta: "Start Free",
    highlighted: false,
  },
  {
    name: "Pro",
    price: "$25",
    period: "/month",
    description: "For professional creators",
    features: [
      "Unlimited Cloud Providers",
      "Share Project feature",
      "Storage Insights & Analytics",
      "Full Metadata Layer",
      "Bulk operations",
      "Priority support",
    ],
    cta: "Start Pro Trial",
    highlighted: true,
    upgradeReasons: [
      "Connect all your cloud storage in one place",
      "Share projects without 'Media Offline' errors",
      "Find and eliminate storage waste",
      "Full metadata and batch operations",
    ],
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-5xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-border/50 bg-secondary/50 px-4 py-1.5 text-sm text-muted-foreground">
            Simple Pricing
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Start free, scale when ready.
          </h2>
          <p className="mt-4 text-pretty text-muted-foreground">
            No hidden fees. Cancel anytime.
          </p>
        </div>

        {/* Primary Plans */}
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`relative overflow-hidden rounded-2xl border p-6 transition-all ${
                plan.highlighted
                  ? "border-primary bg-card/80 shadow-lg shadow-primary/10"
                  : "border-border/50 bg-card/30 hover:border-border hover:bg-card/50"
              }`}
            >
              {plan.highlighted && (
                <div className="absolute top-0 right-0 flex items-center gap-1 rounded-bl-xl bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                  <Sparkles className="h-3 w-3" />
                  Popular
                </div>
              )}

              <div className="mb-4">
                <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{plan.description}</p>
              </div>

              <div className="mb-5">
                <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                {plan.period && (
                  <span className="text-muted-foreground">{plan.period}</span>
                )}
              </div>

              <ul className="mb-6 space-y-2.5">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Check className={`h-4 w-4 shrink-0 ${plan.highlighted ? "text-primary" : "text-chart-2"}`} />
                    {feature}
                  </li>
                ))}
              </ul>

              {/* Pro Upgrade Reasons */}
              {plan.upgradeReasons && (
                <div className="mb-6 rounded-xl border border-primary/20 bg-primary/5 p-4">
                  <p className="mb-3 text-xs font-medium uppercase tracking-wider text-primary">
                    Why upgrade to Pro
                  </p>
                  <ul className="space-y-2">
                    {plan.upgradeReasons.map((reason, k) => (
                      <li key={k} className="flex items-start gap-2 text-sm text-foreground/80">
                        <ArrowRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                        {reason}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <Button
                className={`w-full ${
                  plan.highlighted
                    ? "bg-primary text-primary-foreground hover:bg-primary/90"
                    : "bg-secondary text-foreground hover:bg-secondary/80"
                }`}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>

        {/* Teams Callout */}
        <div className="mt-8 rounded-2xl border border-border/50 bg-card/20 p-6">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary">
                <Users className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">For Teams & Studios</h3>
                <p className="text-sm text-muted-foreground">
                  SSO, team management, whitelabel options, and dedicated support.
                </p>
              </div>
            </div>
            <Button variant="outline" className="shrink-0 bg-transparent">
              Contact Sales
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
