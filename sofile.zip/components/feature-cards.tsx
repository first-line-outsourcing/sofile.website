import { Zap, Eye, Share2 } from "lucide-react"

const features = [
  {
    icon: Zap,
    outcome: "Find any file in seconds",
    how: "Portable index searches across all your buckets locally. No servers, no waiting.",
    proof: "Search petabytes in milliseconds.",
  },
  {
    icon: Eye,
    outcome: "See inside your cloud",
    how: "Auto-generated thumbnails and waveforms replace cryptic filenames.",
    proof: "Preview before you download.",
  },
  {
    icon: Share2,
    outcome: "Share without headaches",
    how: "Export projects with linked cloud assets. Recipients get everything synced.",
    proof: "Zero \"Media Offline\" errors.",
  },
]

export function FeatureCards() {
  return (
    <section id="features" className="relative py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-border/50 bg-secondary/50 px-4 py-1.5 text-sm text-muted-foreground">
            Core Features
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            The Core Trio
          </h2>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {features.map((feature, i) => (
            <div
              key={i}
              className="group relative overflow-hidden rounded-xl border border-border/50 bg-card/50 p-6 backdrop-blur-xl transition-all hover:border-primary/30 hover:bg-card/80"
            >
              <div className="mb-5 flex h-11 w-11 items-center justify-center rounded-xl border border-primary/20 bg-primary/10">
                <feature.icon className="h-5 w-5 text-primary" />
              </div>

              {/* Outcome */}
              <h3 className="text-lg font-semibold text-foreground">
                {feature.outcome}
              </h3>
              
              {/* How */}
              <p className="mt-2.5 text-sm text-muted-foreground leading-relaxed">
                {feature.how}
              </p>

              {/* Proof line */}
              <p className="mt-4 text-xs font-medium text-primary">
                {feature.proof}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
